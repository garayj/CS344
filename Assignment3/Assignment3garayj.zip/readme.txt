To compile, run:

```
gcc -o smallsh smallsh.c
```

To run program:

```
./smallsh
```
